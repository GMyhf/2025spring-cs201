# coding: utf-8
"""
@File        :   iris_tuner.py
@Time        :   2025/03/05 19:09:21
@Author      :   Usercyk
@Description :   Tune the hyperparameters of iris dataset
"""

import itertools
import sys
from contextlib import contextmanager
from typing import Dict, List

import numpy as np
import torch
from sklearn.datasets import load_iris
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm, trange


class TrainConfig:
    """
    The configuration class for training the model
    """
    LEARNING_RATE: float = 0.001
    BATCH_SIZE: int = 32
    NUM_EPOCHS: int = 100
    NUM_FOLDS: int = 5
    REG_LAMBDA: float = 0.01
    HIDDEN_SIZE: int = 10


class DynamicLogger:
    """
    The class to log the output to dynamic files
    """

    def __init__(self):
        self.original_stdout = sys.stdout
        self.current_log = None

    @contextmanager
    def log_to_file(self, filename):
        """
        Log the output to a certain file

        Arguments:
            filename -- The filename to log the output
        """
        try:
            self.current_log = Logger(filename)
            sys.stdout = self.current_log
            yield
        finally:
            self.current_log.close()  # type: ignore
            sys.stdout = self.original_stdout


class Logger:
    """
    The class to log the output both to terminal and the file
    """

    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "w", buffering=1, encoding='utf-8')

    def write(self, message):
        """
        Write the message to both terminal and the file

        Arguments:
            message -- The message to write
        """
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        """
        Flush the output
        """
        self.terminal.flush()
        self.log.flush()

    def close(self):
        """
        Close the file
        """
        self.log.close()


class HyperparameterTuner:
    """
    The class to tune the hyperparameters of the model
    """

    def __init__(self, param_grid: Dict[str, list]):
        self.param_grid = param_grid
        self.logger = DynamicLogger()
        self.results = []

    def generate_combinations(self):
        """
        Generate all possible combinations of hyperparameters

        Yields:
            The next combination of hyperparameters
        """
        keys = self.param_grid.keys()
        values = self.param_grid.values()
        for combination in itertools.product(*values):
            yield dict(zip(keys, combination))

    def _print_config_header(self, params):
        """
        Print the header of the current hyperparameters

        Arguments:
            params -- The current hyperparameters
        """
        print("=" * 50)
        print("Current Hyperparameters:")
        for k, v in params.items():
            print(f"{k}: {v}")
        print("=" * 50 + "\n")

    def run(self):
        """
        Run the hyperparameter tuning process
        """
        original_config = {k: getattr(TrainConfig, k)
                           for k in self.param_grid.keys()}

        try:
            for params in self.generate_combinations():

                filename = self._generate_filename(params)

                with self.logger.log_to_file(filename):
                    self._set_config(params)
                    self._print_config_header(params)

                    trainer = Trainer()
                    final_accuracy = trainer.train()

                    self.results.append({
                        **params,
                        'accuracy': final_accuracy,
                        'log_file': filename
                    })
        finally:
            self._restore_config(original_config)

        self._print_final_summary()

    def _set_config(self, params):
        for key, value in params.items():
            setattr(TrainConfig, key, value)

    def _restore_config(self, original):
        for key, value in original.items():
            setattr(TrainConfig, key, value)

    def _generate_filename(self, params):
        parts = []
        for k, v in params.items():
            if isinstance(v, float):
                v_str = f"{v:.0e}".replace('.', '').replace('e-0', 'e-')
            else:
                v_str = str(v)
            parts.append(f"{k}_{v_str}")
        return f"/home/rocky/assignment2/log/iris_{'_'.join(parts)}.log"

    def _print_final_summary(self):
        print("\n\n=== Hyperparameter Tuning Summary ===")
        for result in self.results:
            print(f"\nConfiguration: {result['log_file']}")
            print(f"Accuracy: {result['accuracy']:.4f}")
            print("-" * 50)


class IrisModel(nn.Module):
    """
    The class to define the model for iris dataset
    """

    def __init__(self, input_size, hidden_size, output_size):
        super().__init__()
        self.layer1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        """
        Forward pass of the model

        Arguments:
            x -- The tensor input

        Returns:
            The tensor output
        """
        x = self.layer1(x)
        x = self.relu(x)
        return self.layer2(x)


class Trainer:
    """
    Trainer class to train the model
    """

    def __init__(self):
        self.scaler = StandardScaler()
        self.criterion = nn.CrossEntropyLoss()

    def train_with_seed(self, seed) -> List[float]:
        """
        Train the model with certain seed

        Arguments:
            seed -- The random seed

        Returns:
            The accuracies of each fold
        """

        torch.manual_seed(seed)
        np.random.seed(seed)

        x, y = load_iris(return_X_y=True)
        x = self.scaler.fit_transform(x)  # type: ignore
        x_tensor = torch.tensor(x, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.long)

        kfold = StratifiedKFold(
            n_splits=TrainConfig.NUM_FOLDS,
            shuffle=True,
            random_state=seed
        )

        accuracies = []
        progress_bar = tqdm(
            kfold.split(x, y),
            total=TrainConfig.NUM_FOLDS,
            desc="CV Progress"
        )

        for fold, (train_idx, val_idx) in enumerate(progress_bar):
            x_train, x_val = x_tensor[train_idx], x_tensor[val_idx]
            y_train, y_val = y_tensor[train_idx], y_tensor[val_idx]

            train_loader = DataLoader(
                TensorDataset(x_train, y_train),
                batch_size=TrainConfig.BATCH_SIZE,
                shuffle=True
            )
            val_loader = DataLoader(
                TensorDataset(x_val, y_val),
                batch_size=TrainConfig.BATCH_SIZE
            )

            model = IrisModel(
                input_size=x.shape[1],
                hidden_size=TrainConfig.HIDDEN_SIZE,
                output_size=len(np.unique(y))
            )
            optimizer = optim.SGD(
                model.parameters(),
                lr=TrainConfig.LEARNING_RATE,
                weight_decay=TrainConfig.REG_LAMBDA
            )

            epoch_bar = trange(
                TrainConfig.NUM_EPOCHS,
                desc=f"Fold {fold+1}",
                leave=False
            )
            for _ in epoch_bar:
                model.train()
                for x_batch, y_batch in train_loader:
                    optimizer.zero_grad()
                    outputs = model(x_batch)
                    loss = self.criterion(outputs, y_batch)
                    loss.backward()
                    optimizer.step()

            model.eval()
            correct, total = 0, 0
            with torch.no_grad():
                for x_batch, y_batch in val_loader:
                    outputs = model(x_batch)
                    _, predicted = torch.max(outputs.data, 1)
                    total += y_batch.size(0)
                    correct += (predicted == y_batch).sum().item()

            fold_acc = correct / total
            accuracies.append(fold_acc)
            progress_bar.set_postfix_str(f"Acc: {fold_acc:.4f}")

        return accuracies

    def train(self):
        """
        Train the model

        Returns:
            The average accuracy of the model
        """
        accuracies = []

        for seed in tqdm([42, 43, 44], desc="Seeds"):
            accuracies.extend(self.train_with_seed(seed))

        final_acc = np.mean(accuracies)
        print("\n=== Final Metrics ===")
        print(f"Average Accuracy: {final_acc:.4f}")
        print(f"Std Deviation: {np.std(accuracies):.4f}")
        print(f"Individual Accuracies: {[round(acc,4) for acc in accuracies]}")

        return final_acc


if __name__ == "__main__":
    parameters = {
        'LEARNING_RATE': [0.0001, 0.001, 0.01],
        'HIDDEN_SIZE': [5, 10, 20],
        'REG_LAMBDA': [0.001, 0.01, 0.1],
        'NUM_EPOCHS': [50, 100, 200]
    }

    tuner = HyperparameterTuner(parameters)
    tuner.run()
