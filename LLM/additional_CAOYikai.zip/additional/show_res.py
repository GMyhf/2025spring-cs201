# coding: utf-8
"""
@File        :   show_res.py
@Time        :   2025/03/05 19:20:55
@Author      :   Usercyk
@Description :   Visualize the results of iris_tuner.py
"""

import os
import re

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import MaxNLocator

LOG_DIR = "assignment2/log"
OUTPUT_IMG = "assignment2/hyperparam_analysis.png"


def parse_log_filename(filename):
    """
    Using the filename to parse the hyperparameters

    Arguments:
        filename -- The filename of the log file

    Returns:
        The dictionary of the hyperparameters
    """
    params = {}
    parts = filename.replace(".log", "").split("_")

    current_key = None
    for part in parts[1:]:
        if part in ["LEARNING", "HIDDEN", "REG", "NUM"]:
            current_key = part
        elif part in ["RATE", "SIZE", "LAMBDA", "EPOCHS"]:
            current_key += "_" + part  # type: ignore
        elif current_key:
            if 'e-' in part:
                params[current_key] = float(part.replace('e-', 'e-'))
            elif part.isdigit():
                params[current_key] = int(part)
            else:
                try:
                    params[current_key] = float(part)
                except Exception:  # pylint: disable=broad-except
                    params[current_key] = part
            current_key = None
    return params


def extract_accuracy(log_path):
    """
    Extract the accuracy from the log file

    Arguments:
        log_path -- The path of the log file

    Returns:
        The accuracy of the model
    """
    with open(log_path, 'r', encoding="utf-8") as f:
        content = f.read()
        match = re.search(r"Average Accuracy: (\d+\.\d+)", content)
        if match:
            return float(match.group(1))
    return None


def load_all_results():
    """
    Load all the results from the log files

    Returns:
        The DataFrame of the results
    """
    results = []

    for filename in os.listdir(LOG_DIR):
        if filename.endswith(".log"):
            filepath = os.path.join(LOG_DIR, filename)
            params = parse_log_filename(filename)
            accuracy = extract_accuracy(filepath)

            if accuracy is not None:
                results.append({
                    **params,
                    "accuracy": accuracy
                })

    return pd.DataFrame(results)


def plot_hyperparam_analysis(df):
    """
    Plot the hyperparameter sensitivity analysis

    Arguments:
        df -- The DataFrame of the results
    """
    plt.figure(figsize=(20, 16))
    plt.suptitle("Hyperparameter Sensitivity Analysis", fontsize=18)

    subplot_config = [
        ('LEARNING_RATE', 'log', 'Learning Rate'),
        ('REG_LAMBDA', 'log', 'L2 Regularization'),
        ('HIDDEN_SIZE', 'linear', 'Hidden Layer Size'),
        ('NUM_EPOCHS', 'linear', 'Training Epochs')
    ]

    for idx, (param, scale, title) in enumerate(subplot_config, 1):
        ax = plt.subplot(2, 2, idx)

        other_params = [p for p in df.columns if p not in [param, 'accuracy']]
        grouped = df.groupby(other_params)

        for name, group in grouped:
            sorted_group = group.sort_values(param)
            ax.plot(sorted_group[param], sorted_group['accuracy'],
                    marker='o', linestyle='--', alpha=0.7,
                    label=f"{', '.join([f'{k}={v}' for k,v in zip(other_params, name)])}")

        ax.set_xscale(scale)
        ax.set_xlabel(title, fontsize=12)
        ax.set_ylabel("Accuracy", fontsize=12)
        ax.set_ylim(0.0, 1.0)
        ax.yaxis.set_major_locator(MaxNLocator(5))
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(OUTPUT_IMG, dpi=300, bbox_inches='tight')
    print(f"The result is saved to: {OUTPUT_IMG}")


def find_best_parameters(df):
    """
    Find the best hyperparameters

    Arguments:
        df -- The DataFrame of the results
    """
    best_idx = df['accuracy'].idxmax()
    best_params = df.loc[best_idx].to_dict()

    print("\nBest parameters:")
    for k, v in best_params.items():
        if k == 'accuracy':
            print(f"Ave accuracy: {v:.4f}")
        else:
            print(f"{k}: {v}")


if __name__ == "__main__":
    data_frame = load_all_results()

    data_frame = data_frame.sort_values('accuracy', ascending=False)

    print("Top 5 Best Result:")
    print(data_frame.head(5).to_string(index=False))

    find_best_parameters(data_frame)

    plot_hyperparam_analysis(data_frame)
